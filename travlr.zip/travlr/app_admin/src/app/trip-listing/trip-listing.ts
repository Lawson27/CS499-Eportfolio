import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { Trip } from '../models/trip';
import { TripCard } from '../trip-card/trip-card'
import { TripData } from '../services/trip-data';

import { Router } from '@angular/router';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
  providers: [TripData]
})
export class TripListingComponent implements OnInit {
  trips: Trip[] = [];
  filteredTrips: Trip[] = [];
  message: string = '';
  searchTerm: string = '';
  sortField: string = 'name';


  constructor(
    private tripData: TripData,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private authenticationService: Authentication
  )
  {
    console.log('trip-listing constructor');
  }

  public isLoggedIn() {
    return this.authenticationService.isLoggedIn();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  public applyFiltersAndSorting(): void {
    let processedTrips = [...this.trips];

    if (this.searchTerm.trim()) {
      const term = this.searchTerm.toLowerCase();

      processedTrips = processedTrips.filter((trip: Trip) =>
        trip.name.toLowerCase().includes(term) ||
        trip.resort.toLowerCase().includes(term)
      );
    }

    processedTrips.sort((a: Trip, b: Trip) => {
      const aValue = String(a[this.sortField as keyof Trip]).toLowerCase();
      const bValue = String(b[this.sortField as keyof Trip]).toLowerCase();

      return aValue.localeCompare(bValue);
    });

    this.filteredTrips = processedTrips;
  }

  private getStuff(): void {
    this.tripData.getTrips()
      .subscribe({
        next: (value: any) => {
          this.trips = value;
          console.log('Trips from API:', this.trips);
          this.applyFiltersAndSorting();
          this.cdr.detectChanges(); // <-- makes the UI update immediately
          if (value.length > 0) {
            this.message = 'there are ' + 'trips available.';
          }
          else {
            this.message = "there were no trips retrieved from the database";
          }
          console.log(this.message);
        },
        error: (error: any) => {
          console.log("Error: " + error);
        }
      })
  }
  ngOnInit(): void {
    console.log('ngOnInit');
    this.getStuff();
    }
  }
