const mongoose = require('mongoose');

// Define the trip schema
const tripSchema = new mongoose.Schema({
    code: {
        type: String,
        required: true,
        trim: true,
        uppercase: true
    },
    name: {
        type: String,
        required: true,
        trim: true,
    },
    length: {
        type: String,
        required: true,
        trim: true
    },
    start: {
        type: Date,
        required: true
    },
    resort: {
        type: String,
        required: true,
        trim: true
    },
    perPerson: {
        type: String,
        required: true,
        trim: true
    },
    image: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true,
        trim: true,
        minlength: 10
    }
});

//Database indexing to improve data integrity and query performance.
tripSchema.index({ code: 1 }, { unique: true });
tripSchema.index({ start: 1 });
tripSchema.index({ resort: 1, start: 1 });

const Trip = mongoose.model('trips', tripSchema);
module.exports = Trip;