const jwt = require('jsonwebtoken');

function authenticateJWT(req, res, next) {
    const authHeader = req.headers['authorization'];

    if (!authHeader) {
        return res.status(401).json({ message: 'Authorization header required.' });
    }

    const headers = authHeader.split(' ');

    if (headers.length !== 2 || headers[0] !== 'Bearer') {
        return res.status(401).json({ message: 'Authorization header must use Bearer token format.' });
    }

    const token = headers[1];

    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            return res.status(401).json({ message: 'Invalid or expired token.' });
        }

        req.auth = verified;
        return next();
    });

    
}
module.exports = authenticateJWT;