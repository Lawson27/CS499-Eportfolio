const mongoose = require('mongoose');
const Trip = require('../models/travlr'); // Register model
const Model = mongoose.model('trips');
//PUT: /trips/:tripCode - Adds a new Trip
//Regardless of outcome, response must include HTML status code
//and JSON message to the requesting client 
const tripsUpdateTrip = async (req, res) => {
    if (!req.body.code || !req.body.name) {
        return res.status(400).json({
            message: "Trip code and name are required."
        });
    }
    //Uncomment for debugging
    //console.log(req.params);
    //console.log(req.body);

    try {
        const q = await Model
            .findOneAndUpdate(
                { 'code': req.params.tripCode },
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                { new: true }
            )
            .exec();

        if (!q) {
            return res.status(404).json({
                message: `Trip with code ${req.params.tripCode} was not found.`
            });
        }

        return res.status(200).json(q);
    } catch (error) {
        return res.status(500).json({
            message: "An unexpected error occurred while updating the trip.",
            error: error.message
        });
    }


    //Uncomment the following line to show results of operation
    // console.log(q);
};

// GET: /trips - lists all the trips
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client.
const tripsAddTrip = async (req, res) => {

    if (!req.body.code || !req.body.name) {
        return res.status(400).json({
            message: "Trip code and name are required."
        });
    }
    try {
        const newTrip = new Trip({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        const q = await newTrip.save();

        return res.status(201).json(q);

    } catch (error) {
        return res.status(500).json({
            message: "An unexpected error occured while adding the trip.",
            error: error.message
        });
    }
};

const tripsList = async (req, res) => {
    try {
        const q = await Model
            .find({}) //No filter, return all records
            .exec();

        return res.status(200).json(q);
    }

    catch (error) {
        return res
            .status(500)
            .json({
                message: "Unable to retrieve trips.",
                error: error.message
            });
    }

    //Uncomment the following ine to show results of query
    //on the console
    //console.log(q);

};

// GET: /trips/:tripCode - lists a single trip
// Regardless of outcome, response must include HTML status code
// and JSON message to the requesting client.
const tripsFindByCode = async (req, res) => {

    try {
        const q = await Model
            .find({ 'code': req.params.tripCode }) // Return a single record
            .exec();

        if (q.length === 0) {
            return res.status(404).json({
                message: `Trip with code ${req.params.tripCode} was not found.`
            });
        }
        return res.status(200).json(q);
    }
    catch (error) {
        return res.status(500).json({
            message: "An Unexpected error occurred while retrieving the trip.",
            error: error.message
        });
    }

    //Uncomment the following ine to show results of query
    //on the console
    //console.log(q);

};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};