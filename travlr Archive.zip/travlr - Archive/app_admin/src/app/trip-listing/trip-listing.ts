import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Trip } from '../models/trip';
import { TripCard } from '../trip-card/trip-card'
import { TripData } from '../services/trip-data';

import { Router } from '@angular/router';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  standalone: true,
  imports: [CommonModule, TripCard],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
  providers: [TripData]
})
export class TripListingComponent implements OnInit {
  trips!: Trip[];
  message: string = '';


  constructor(
    private tripData: TripData,
    private router: Router,
    private cdr: ChangeDetectorRef,
    private authenticationService: Authentication
  )
  {
    console.log('trip-listing constructor');
  }

  public isLoggedIn() {
    return this.authenticationService.isLoggedIn();
  }

  public addTrip(): void {
    this.router.navigate(['add-trip']);
  }

  private getStuff(): void {
    this.tripData.getTrips()
      .subscribe({
        next: (value: any) => {
          this.trips = value;
          this.cdr.detectChanges(); // <-- makes the UI update immediately
          if (value.length > 0) {
            this.message = 'there are ' + 'trips available.';
          }
          else {
            this.message = "there were no trips retrieved from the database";
          }
          console.log(this.message);
        },
        error: (error: any) => {
          console.log("Error: " + error);
        }
      })
  }
  ngOnInit(): void {
    console.log('ngOnInit');
    this.getStuff();
    }
  }
