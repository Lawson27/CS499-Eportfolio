export const trips = [
  {
    "code": "GALR210214",
    "name": "Gale Reef",
    "length": "4 nights / 5 days",
    "start": "2021-02-14T08:00:00Z",
    "resort": "Emerald Bay, 3 stars",
    "perPerson": "799.00",
    "image": "reef1.jpg",
    "description": "<p>Gale Reef Sed et augue lorem. In sit amet placerat arcu. Mauris\nvolutpat ipsum ac justo mollis vel vestibulum orci\ngravid a. Vestibulum sit amet porttitor odio. Nulla\nfacilisi. Fusce at pretium felis.\n</p>\n<p>\nSed consequat libero ut turpis venenatis ut aliquam risus\nsemper. Etiam convallis mi vel risus pretium sodales.\nEtiam nunc lorem ullamcorper vitae laoreet.\n</p>"
  },
  {
    "code": "DAWR210315",
    "name": "Dawson's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-03-15T08:00:00Z",
    "resort": "Blue Lagoon, 4 stars",
    "perPerson": "1199.00",
    "image": "reef2.jpg",
    "description": "<p>Dawson's Reef Integer magna leo, posuere et dignissim vitae, porttitor\nat odio. Pellentesque a metus nec magna placerat volutpat.\nNunc nisi mi, elementum sit amet aliquet quis, tristique\nquis nisl. Curabitur odio lacus, blandit ut hendrerit\n</p>\n<p>\nvulputate, vulputate at est. Morbi aliquet viverra metus\neu consectetur. In lorem dui, elementum sit amet convallis\nac, tincidunt vel sapien.\n</p>"
  },
  {
    "code": "CLAR210621",
    "name": "Claire's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-06-21T08:00:00Z",
    "resort": "Coral Sands, 5 stars",
    "perPerson": "1999.00",
    "image": "reef3.jpg",
    "description": "<p>Claire's Reef Donec sed felis risus. Nulla facilisi. Donec a orci\ntellus, et auctor odio. Fusce ac orci nibh, quis semper\narcu. Cras orci neque, euismod et accumsan ac, sagittis\nmolestie lorem. Proin odio sapien, elementum at tempor\nnon.\n</p>\n<p>\nVulputate eget libero. In hac habitasse platea dictumst.\nInteger purus justo, egestas eu consectetur eu, cursus in\ntortor. Quisque nec nunc ac mi ultrices iaculis.\n</p>"
  }
];
